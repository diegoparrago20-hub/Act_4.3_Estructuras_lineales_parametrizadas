/*
 Equipo #2
 CONTRERAS RODRIGUEZ JANIS ISABEL
 LIRA DOMINGUEZ BRYANT 
 PARRA GONZALEZ DIEGO ALBERTO
 */
package back_end;

import java.util.Objects;
/**
 *
 * @author coter
 */
public class Articulo extends Trabajo {
    private String nombreConferencia;

    public Articulo() { 
        
    }

    public Articulo(String titulo, String autor, int anioPublicacion, String nombreConferencia) {
        super(titulo, autor, anioPublicacion);
        this.nombreConferencia = nombreConferencia;
    }

    public String getNombreConferencia() { 
        return nombreConferencia; 
    }
    public void setNombreConferencia(String nombreConferencia) { 
        this.nombreConferencia = nombreConferencia; 
    }

    @Override
    public int hashCode() {
        return Objects.hash(super.hashCode(), nombreConferencia);
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        if (!super.equals(o)) return false;
        Articulo a = (Articulo) o;
        return Objects.equals(nombreConferencia, a.nombreConferencia);
    }

    @Override
    public String toString() {
        return "ARTÍCULO: " + super.toString() + " | Conferencia: " + nombreConferencia;
    }
}//Final
