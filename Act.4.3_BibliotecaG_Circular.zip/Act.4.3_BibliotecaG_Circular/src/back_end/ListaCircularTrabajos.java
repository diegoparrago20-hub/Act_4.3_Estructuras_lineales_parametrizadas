/*
 Equipo #2
 CONTRERAS RODRIGUEZ JANIS ISABEL
 LIRA DOMINGUEZ BRYANT 
 PARRA GONZALEZ DIEGO ALBERTO
 */
package back_end;
/**
 *
 * @author coter
 */
public class ListaCircularTrabajos <T extends Trabajo> {
    private Nodo<T> primero;
    private Nodo<T> ultimo;
    private Nodo<T> actual;   // cursor de navegación
    private int tamaño;
    
    public ListaCircularTrabajos() {
        this.primero = null;
        this.ultimo = null;
        this.actual = null;
        this.tamaño = 0;
    }
    
//insertarInicio(T trabajo) / insertarFinal(T trabajo): agrega un nuevo trabajo al inicio o al final de la lista circular, manteniendo la referencia de cierre.
    public void insertarPrincipio(T dato) {
        Nodo<T> nuevo = new Nodo<>(dato);
        if (isEmpty()) {
            primero = nuevo;
            ultimo = nuevo;
            actual = nuevo;
            nuevo.setSiguiente(nuevo);
            nuevo.setAnterior(nuevo);
        } else {
            nuevo.setSiguiente(primero);
            nuevo.setAnterior(ultimo);
            primero.setAnterior(nuevo);
            ultimo.setSiguiente(nuevo);
            primero = nuevo;
            actual = nuevo;
        }
        tamaño++;
    }
    public void insertarFinal(T dato) {
        Nodo<T> nuevo = new Nodo<>(dato);
        if (isEmpty()) {
            primero = nuevo;
            ultimo = nuevo;
            actual = nuevo;
            nuevo.setSiguiente(nuevo);
            nuevo.setAnterior(nuevo);
        } else {
            nuevo.setSiguiente(primero);
            nuevo.setAnterior(ultimo);
            ultimo.setSiguiente(nuevo);
            primero.setAnterior(nuevo);
            ultimo = nuevo;
            actual = nuevo;
        }
        tamaño++;
    }

//insertarPosicion(T trabajo, int posicion): inserta una publicación en una posición específica de la lista circular.
    public void insertarPosicion(T dato, int posicion) {
        if (posicion < 0 || posicion > tamaño) {
            throw new IndexOutOfBoundsException("Posición fuera de rango. Válida: 0 a " + tamaño);
        }
        if (posicion == 0) {
            insertarPrincipio(dato);
        } else if (posicion == tamaño) {
            insertarFinal(dato);
        } else {
            Nodo<T> nuevo = new Nodo<>(dato);
            Nodo<T> aux = primero;
            for (int i = 0; i < posicion - 1; i++) {
                aux = aux.getSiguiente();
            }
            Nodo<T> siguiente = aux.getSiguiente();

            nuevo.setSiguiente(siguiente);
            nuevo.setAnterior(aux);
            aux.setSiguiente(nuevo);
            siguiente.setAnterior(nuevo);
            actual = nuevo;
            tamaño++;
        }
    }
    
//eliminar(int posicion) / eliminarPorTitulo(String titulo): remueve el nodo correspondiente ajustando los enlaces del elemento anterior y posterior.
    public T eliminar(int posicion) {
        if (isEmpty()) {
            return null;
        }
        if (posicion < 0 || posicion >= tamaño) {
            throw new IndexOutOfBoundsException("Posición fuera de rango. Válida: 0 a " + (tamaño - 1));
        }

        if (posicion == 0) {
            return eliminarPrincipio();
        }
        if (posicion == tamaño - 1) {
            return eliminarFinal();
        }

        Nodo<T> aux = primero;
        for (int i = 0; i < posicion; i++) {
            aux = aux.getSiguiente();
        }

        if (aux == actual) {// Si el cursor apunta al nodo que se va, lo movemos antes de desenlazar
            actual = aux.getSiguiente();
        }

        Nodo<T> anterior = aux.getAnterior();
        Nodo<T> siguiente = aux.getSiguiente();

        anterior.setSiguiente(siguiente);
        siguiente.setAnterior(anterior);
        tamaño--;
        return aux.getDato();
    }
    public T eliminarPrincipio() {
        if (isEmpty()) {
            return null;
        }
        T dato = primero.getDato();
        if (tamaño == 1) {
            primero = null;
            ultimo = null;
            actual = null;
        } else {
            Nodo<T> nuevoPrimero = primero.getSiguiente();
            nuevoPrimero.setAnterior(ultimo);
            ultimo.setSiguiente(nuevoPrimero);
            if (actual == primero) {
                actual = nuevoPrimero;
            }
            primero = nuevoPrimero;
            if (tamaño == 2) {              // queda uno solo: se cierra sobre sí mismo
                primero.setSiguiente(primero);
                primero.setAnterior(primero);
                ultimo = primero;
            }
        }
        tamaño--;
        return dato;
    } // ayudan eliminar
    public T eliminarFinal() {
        if (isEmpty()) {
            return null;
        }
        T dato = ultimo.getDato();
        if (tamaño == 1) {
            primero = null;
            ultimo = null;
            actual = null;
        } else {
            Nodo<T> nuevoUltimo = ultimo.getAnterior();
            nuevoUltimo.setSiguiente(primero);
            primero.setAnterior(nuevoUltimo);
            if (actual == ultimo) {
                actual = primero;
            }
            ultimo = nuevoUltimo;
            if (tamaño == 2) {              // queda uno solo: se cierra sobre sí mismo
                primero.setSiguiente(primero);
                primero.setAnterior(primero);
                ultimo = primero;
            }
        }
        tamaño--;
        return dato;
    } // ayudan eliminar
    public T eliminarPorTitulo(String titulo) {
        if (isEmpty() || titulo == null) {
            return null;
        }
        Nodo<T> aux = primero;
        for (int i = 0; i < tamaño; i++) {
            if (aux.getDato().getTitulo().equalsIgnoreCase(titulo.trim())) {
                return eliminar(i);
            }
            aux = aux.getSiguiente();
        }
        return null;   // no encontrado
    }
    
//siguiente() / anterior(): desplaza el apuntador o cursor actual al nodo siguiente o anterior dentro del ciclo de la lista.
    public T siguiente() {
        if (isEmpty()) {
            return null;
        }
        actual = actual.getSiguiente();
        return actual.getDato();
    }
    public T anterior() {
        if (isEmpty()) {
            return null;
        }
        actual = actual.getAnterior();
        return actual.getDato();
    }

//consultarActual(): devuelve la información del trabajo seleccionado actualmente por el cursor de navegación.
    public T consultarActual() {
        return isEmpty() ? null : actual.getDato();
    }

//mostrarTodos(): genera la secuencia completa de la lista circular desde el nodo cabeza hasta completar un ciclo entero.
    public String mostrarTodos() {
        if (isEmpty()) {
            return "La lista circular está vacía";
        }
        StringBuilder sb = new StringBuilder();
        Nodo<T> aux = primero;
        int i = 0;
        do {
            sb.append(i).append(". ").append(aux.getDato());
            if (aux == primero) {
                sb.append("   [CABEZA]");
            }
            if (aux == actual) {
                sb.append("   <== ACTUAL");
            }
            sb.append("\n");
            aux = aux.getSiguiente();
            i++;
        } while (aux != primero);
        sb.append("\n");
    sb.append("Recorrido: ");
    for (int j = 0; j < tamaño; j++) {
        sb.append(j).append(" -> ");
    }
    sb.append("(0 = cabeza)\n");

    int indiceActual = 0;
    Nodo<T> aux2 = primero;
    for (int j = 0; j < tamaño; j++) {
        if (aux2 == actual) {
            indiceActual = j;
            break;
        }
        aux2 = aux2.getSiguiente();
    }
    sb.append("Tamaño: ").append(tamaño).append(" nodo(s)")
      .append(" | Cursor actual: índice ").append(indiceActual).append("\n");
        return sb.toString();
    }

//isEmpty(): comprueba si la lista circular no contiene elementos.
    public boolean isEmpty() {
        return primero == null;
    }

//vaciarLista(): elimina todos los nodos y restablece la estructura.
    public void vaciar() {
        primero = null;
        ultimo = null;
        actual = null;
        tamaño = 0;
    }

// auxiliares para las etiquetas   
    public int tamaño() {
        return tamaño;
    }
    public T consultarInicio() {
        return isEmpty() ? null : primero.getDato();
    }
} // Final
