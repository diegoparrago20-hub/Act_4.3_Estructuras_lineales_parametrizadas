/*
 Equipo #2
 CONTRERAS RODRIGUEZ JANIS ISABEL
 LIRA DOMINGUEZ BRYANT 
 PARRA GONZALEZ DIEGO ALBERTO
 */
package back_end;

import java.util.Objects;
/**
 *
 * @author coter
 */
public class Libro extends Trabajo {
    private int numeroPaginas;

    public Libro() { 
    }

    public Libro(String titulo, String autor, int anioPublicacion, int numeroPaginas) {
        super(titulo, autor, anioPublicacion);
        this.numeroPaginas = numeroPaginas;
    }

    public int getNumeroPaginas() { 
        return numeroPaginas; 
    }
    public void setNumeroPaginas(int numeroPaginas) { 
        this.numeroPaginas = numeroPaginas; 
    }
    
    @Override
    public int hashCode() {
        return Objects.hash(super.hashCode(), numeroPaginas);
    }
    
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        if (!super.equals(o)) return false;
        Libro l = (Libro) o;
        return numeroPaginas == l.numeroPaginas;
    }

    @Override
    public String toString() {
        return "LIBRO: " + super.toString() + " | Páginas: " + numeroPaginas;
    }
    
}//Final
