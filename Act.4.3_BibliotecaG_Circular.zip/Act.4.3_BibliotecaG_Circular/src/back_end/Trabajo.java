/*
 Equipo #2
 CONTRERAS RODRIGUEZ JANIS ISABEL
 LIRA DOMINGUEZ BRYANT 
 PARRA GONZALEZ DIEGO ALBERTO
 */
package back_end;

import java.util.Objects;

/**
 *
 * @author coter
 */
public class Trabajo {
    private String titulo;
    private String autor;
    private int anioPublicacion;

    public Trabajo() {
    }

    public Trabajo(String titulo, String autor, int anioPublicacion) {
        this.titulo = titulo;
        this.autor = autor;
        this.anioPublicacion = anioPublicacion;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public String getAutor() {
        return autor;
    }

    public void setAutor(String autor) {
        this.autor = autor;
    }

    public int getAnioPublicacion() {
        return anioPublicacion;
    }

    public void setAnioPublicacion(int anioPublicacion) {
        this.anioPublicacion = anioPublicacion;
    }
    
    @Override
    public int hashCode() {
        return Objects.hash(titulo, autor, anioPublicacion);
    }
    
     @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Trabajo t = (Trabajo) o;
        return anioPublicacion == t.anioPublicacion
                && Objects.equals(titulo, t.titulo)
                && Objects.equals(autor, t.autor);
    }

    @Override
    public String toString() {
        return "Título: " + titulo + " | Autor: " + autor + " | Año: " + anioPublicacion;
    }
    
}// Fianl
